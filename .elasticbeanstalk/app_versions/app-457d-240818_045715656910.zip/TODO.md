TODO

Yadd s3 OK
Ysecure s3 with credentials OK
Yhost in s3 X

WIPget a domain OK

block direct download from s3 ??
store s3 link ??
share encrypted link XX
test stripe checkout OK
test checkout product link OK
add 1 day expire for purchased products OK
create landing page OK